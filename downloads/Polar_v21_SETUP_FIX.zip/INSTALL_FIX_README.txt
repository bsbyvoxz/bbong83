Python runtime setup fix for Polar v21

Extract these files into the EXISTING project directory containing polar_v18.py.
Allow SETUP.bat to be replaced, then run SETUP.bat again.
The script reuses compatible 64-bit Python 3.10-3.13, or tries py install 3.12.
No game logic or calibration files are replaced.
